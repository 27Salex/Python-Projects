print("Càlculs aritmétics")
Num1 = int(input("Introdueix el primer número:   "))
Num2 = int(input("Introdueix el segon número:   "))
ResultatSuma = Num1 + Num2
ResultatResta = Num1 - Num2
ResultatMulti = Num1 * Num2
ResultatDivisio = Num1 / Num2
ResultatPotencies = Num1**2 +  Num2**2

print("La suma de %d y %d és: %d" %(Num1, Num2, ResultatSuma))
print("La resta de %d y %d és: %d" %(Num1, Num2, ResultatResta))
print("La Multiplicació de %d y %d és: %d" %(Num1, Num2, ResultatMulti))
print("La suma dels cuadrats de %d y %d és: %d" %(Num1, Num2, ResultatPotencies))