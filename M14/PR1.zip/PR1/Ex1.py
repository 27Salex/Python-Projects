print("Càlcul mitjana aritmética")
Num1 = int(input("Introdueix el primer número:   "))
Num2 = int(input("Introdueix el segon número:   "))
Resultat = Num1 + Num2 /  2
print("La mitjana aritmetica de %d y %d és: %10.2f" %(Num1, Num2, Resultat))