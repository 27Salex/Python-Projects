print("Càlcul 30%")
preuOriginal = float(input("Introdueix el preu del producte:   "))
preuAgumentat = float( preuOriginal + preuOriginal * 0.3)
print("El preu amb beneficis de %3.2f€ és %3.2f€" %(preuOriginal, preuAgumentat))